package ipos.ca.login.model;

/**
 * Represents a staff user of IPOS-CA.
 * Corresponds to UC1 / UC10 – accounts created by Admin with an assigned role.
 */
public class User {

    private int    userId;
    private String username;
    private String password;   // plain text for mock – hash in production
    private String fullName;
    private String email;
    private UserRole role;
    private boolean active;   // false = deleted / suspended

    public User(int userId, String username, String password,
                String fullName, String email, UserRole role) {
        this.userId   = userId;
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.email    = email;
        this.role     = role;
        this.active   = true;
    }

    // -----------------------------------------------------------------------
    // Getters / setters
    // -----------------------------------------------------------------------

    public int       getUserId()   { return userId; }
    public String    getUsername() { return username; }
    public String    getPassword() { return password; }
    public String    getFullName() { return fullName; }
    public String    getEmail()    { return email; }
    public UserRole  getRole()     { return role; }
    public boolean   isActive()    { return active; }

    public void setPassword(String password) { this.password = password; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public void setEmail(String email)       { this.email    = email; }
    public void setRole(UserRole role)       { this.role     = role; }
    public void setActive(boolean active)    { this.active   = active; }

    @Override
    public String toString() {
        return "User{id=" + userId + ", username='" + username +
               "', role=" + role + ", active=" + active + "}";
    }
}
