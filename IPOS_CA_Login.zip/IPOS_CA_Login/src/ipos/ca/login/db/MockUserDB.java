package ipos.ca.login.db;

import ipos.ca.login.model.User;
import ipos.ca.login.model.UserRole;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * MockUserDB – stands in for the real IPOS-CA USER database.
 * Seeded with one user per role so the system works out of the box.
 * Replace this class with real DB calls when the database is ready.
 */
public class MockUserDB {

    private static final List<User> users = new ArrayList<>();
    private static int nextId = 4; // auto-increment counter

    static {
        // Seed data – UC1 says admin creates accounts with username + password
        users.add(new User(1, "admin",      "Admin1234",  "Alice Admin",   "alice@infopharma.com",  UserRole.ADMIN));
        users.add(new User(2, "pharmacist", "Pharma1234", "Bob Boots",     "bob@infopharma.com",    UserRole.PHARMACIST));
        users.add(new User(3, "manager",    "Manager123", "Carol Chemist", "carol@infopharma.com",  UserRole.MANAGER));
    }

    // -----------------------------------------------------------------------
    // Lookup
    // -----------------------------------------------------------------------

    /** Returns user if username + password match and account is active. */
    public static Optional<User> authenticate(String username, String password) {
        return users.stream()
                .filter(u -> u.getUsername().equals(username)
                          && u.getPassword().equals(password)
                          && u.isActive())
                .findFirst();
    }

    /** Find by username only (for admin operations). */
    public static Optional<User> findByUsername(String username) {
        return users.stream()
                .filter(u -> u.getUsername().equals(username))
                .findFirst();
    }

    /** Find by ID. */
    public static Optional<User> findById(int userId) {
        return users.stream()
                .filter(u -> u.getUserId() == userId)
                .findFirst();
    }

    /** All users (for admin table view). */
    public static List<User> getAllUsers() {
        return new ArrayList<>(users);
    }

    // -----------------------------------------------------------------------
    // Create / Delete / Update  (UC1, UC2, UC10)
    // -----------------------------------------------------------------------

    /**
     * UC1 – Create new user account.
     * @return the new User, or null if username already taken.
     */
    public static User createUser(String username, String password,
                                  String fullName, String email, UserRole role) {
        if (findByUsername(username).isPresent()) {
            return null; // alternative flow: username already exists
        }
        User u = new User(nextId++, username, password, fullName, email, role);
        users.add(u);
        return u;
    }

    /**
     * UC2 – Delete (deactivate) a user account.
     * @return true on success, false if not found.
     */
    public static boolean deleteUser(int userId) {
        Optional<User> opt = findById(userId);
        if (opt.isEmpty()) return false;
        opt.get().setActive(false);
        return true;
    }

    /**
     * UC10 – Assign / change role.
     * @return true on success.
     */
    public static boolean assignRole(int userId, UserRole role) {
        Optional<User> opt = findById(userId);
        if (opt.isEmpty()) return false;
        opt.get().setRole(role);
        return true;
    }
}
