package ipos.ca.login;

import ipos.ca.login.view.LoginFrame;

import javax.swing.*;

/**
 * Main – entry point for the IPOS-CA Login package.
 * Run this class to start the application.
 *
 * Mock credentials (seeded in MockUserDB):
 *   admin       / Admin1234   → Admin role  → UserManagementFrame
 *   pharmacist  / Pharma1234  → Pharmacist  → PlaceholderFrame
 *   manager     / Manager123  → Manager     → PlaceholderFrame
 */
public class Main {
    public static void main(String[] args) {
        // Run on the Event Dispatch Thread
        SwingUtilities.invokeLater(LoginFrame::new);
    }
}
