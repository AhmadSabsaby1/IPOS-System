package ipos.ca.login.controller;

import ipos.ca.login.db.MockUserDB;
import ipos.ca.login.model.Session;
import ipos.ca.login.model.User;
import ipos.ca.login.model.UserRole;

import java.util.List;

/**
 * UserAdminController – business logic for:
 *   UC1  – Create new user account
 *   UC2  – Delete user account
 *   UC10 – Assign role
 *
 * All methods check that the caller is an Admin (UC1 primary actor = Admin).
 */
public class UserAdminController {

    /**
     * UC1 – Create new user account (Admin only).
     * Post-condition: account is created and (mock) email sent with credentials.
     *
     * @return created User, or null if username already taken or caller not Admin.
     */
    public User createUser(String username, String password,
                           String fullName, String email, UserRole role) {
        if (!callerIsAdmin()) {
            System.err.println("[UserAdmin] Access denied – caller is not Admin.");
            return null;
        }
        if (username == null || username.isBlank()) return null;
        if (password == null || password.isBlank()) return null;

        User created = MockUserDB.createUser(username, password, fullName, email, role);
        if (created == null) {
            System.out.println("[UserAdmin] Create failed – username already exists: " + username);
        } else {
            // UC1 post-condition: "Username and password are emailed to the user."
            sendWelcomeEmail(created);
            System.out.println("[UserAdmin] Created: " + created);
        }
        return created;
    }

    /**
     * UC2 – Delete user account (Admin only).
     * Post-condition: user can no longer log in.
     *
     * @return true on success.
     */
    public boolean deleteUser(int userId) {
        if (!callerIsAdmin()) {
            System.err.println("[UserAdmin] Access denied – caller is not Admin.");
            return false;
        }
        boolean ok = MockUserDB.deleteUser(userId);
        System.out.println("[UserAdmin] Delete user " + userId + ": " + (ok ? "success" : "not found"));
        return ok;
    }

    /**
     * UC10 – Assign role (Admin only).
     * @return true on success.
     */
    public boolean assignRole(int userId, UserRole role) {
        if (!callerIsAdmin()) {
            System.err.println("[UserAdmin] Access denied – caller is not Admin.");
            return false;
        }
        boolean ok = MockUserDB.assignRole(userId, role);
        System.out.println("[UserAdmin] Assign role " + role + " to user " + userId + ": " + (ok ? "success" : "not found"));
        return ok;
    }

    /** Returns all users – for displaying in the admin table. */
    public List<User> getAllUsers() {
        if (!callerIsAdmin()) return List.of();
        return MockUserDB.getAllUsers();
    }

    // -----------------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------------

    private boolean callerIsAdmin() {
        return Session.getInstance().hasRole(UserRole.ADMIN);
    }

    /** Mock email send – replace with real SMTP / IPOS-PU COMMS call later. */
    private void sendWelcomeEmail(User user) {
        System.out.println("[MockEmail] To: " + user.getEmail()
                + " | Subject: Your IPOS-CA account"
                + " | Username: " + user.getUsername()
                + " | Password: " + user.getPassword());
    }
}
